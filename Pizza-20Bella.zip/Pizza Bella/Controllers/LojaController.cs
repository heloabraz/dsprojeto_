using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PizzaBella.Data;
using PizzaBella.Models;

namespace PizzaBella.Controllers;

public class LojaController : Controller
{
    private readonly PizzaBellaContext _context;
    public LojaController(PizzaBellaContext context) => _context = context;

    [HttpGet]
    public IActionResult Pedido() => View(new PedidoOnlineViewModel());

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Pedido(PedidoOnlineViewModel dados)
    {
        var pizzas = new[] { "Calabresa", "Mussarela", "Frango com Catupiry", "Portuguesa", "Quatro Queijos" };
        var tamanhos = new[] { "Pequena", "Média", "Grande", "Família" };
        var pagamentos = new[] { "Pix", "Cartão", "Dinheiro" };
        if (!pizzas.Contains(dados.Pizza) || !tamanhos.Contains(dados.Tamanho) || !pagamentos.Contains(dados.Pagamento))
            ModelState.AddModelError(string.Empty, "Confira a pizza, o tamanho e a forma de pagamento escolhidos.");
        if (!ModelState.IsValid) return View(dados);

        var email = dados.Email.Trim().ToLowerInvariant();
        var cliente = await _context.Clientes.FirstOrDefaultAsync(c => c.Email.ToLower() == email);
        if (cliente == null)
        {
            cliente = new Cliente
            {
                Nome = dados.Nome.Trim(), Email = email, Telefone = dados.Telefone.Trim(),
                Endereco = dados.Endereco.Trim(), Cidade = dados.Cidade.Trim()
            };
            _context.Clientes.Add(cliente);
        }
        else
        {
            cliente.Nome = dados.Nome.Trim();
            cliente.Telefone = dados.Telefone.Trim();
            cliente.Endereco = dados.Endereco.Trim();
            cliente.Cidade = dados.Cidade.Trim();
        }

        var precos = new Dictionary<string, decimal> { ["Pequena"] = 25m, ["Média"] = 35m, ["Grande"] = 45m, ["Família"] = 58m };
        var pedido = new Pedido
        {
            Cliente = cliente, Pizza = dados.Pizza, Tamanho = dados.Tamanho,
            Quantidade = dados.Quantidade, Pagamento = dados.Pagamento,
            Observacoes = string.IsNullOrWhiteSpace(dados.Observacoes) ? null : $"Entrega: {dados.Endereco}, {dados.Cidade}. {dados.Observacoes.Trim()}",
            Status = "Recebido", DataPedido = DateTime.Now,
            ValorTotal = precos[dados.Tamanho] * dados.Quantidade
        };
        _context.Pedidos.Add(pedido);
        await _context.SaveChangesAsync();
        return RedirectToAction(nameof(Confirmacao), new { id = pedido.Id });
    }

    [HttpGet]
    public async Task<IActionResult> Confirmacao(int id)
    {
        var pedido = await _context.Pedidos.Include(p => p.Cliente).FirstOrDefaultAsync(p => p.Id == id);
        return pedido == null ? NotFound() : View(pedido);
    }
}
