using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PizzaBella.Data;
using PizzaBella.Models;

namespace PizzaBella.Controllers;

public class PedidosController : Controller
{
    private readonly PizzaBellaContext _context;
    public PedidosController(PizzaBellaContext context) => _context = context;

    public async Task<IActionResult> Index(string? busca, string? status)
    {
        var consulta = _context.Pedidos.Include(p => p.Cliente).AsQueryable();
        if (!string.IsNullOrWhiteSpace(busca))
            consulta = consulta.Where(p => p.Cliente!.Nome.Contains(busca) || p.Pizza.Contains(busca));
        if (!string.IsNullOrWhiteSpace(status)) consulta = consulta.Where(p => p.Status == status);
        ViewBag.Busca = busca;
        ViewBag.Status = status;
        return View(await consulta.OrderByDescending(p => p.DataPedido).ToListAsync());
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> AtualizarStatus(int id, string status)
    {
        var permitidos = new[] { "Recebido", "Em preparo", "Saiu para entrega", "Concluído", "Cancelado" };
        var pedido = await _context.Pedidos.FindAsync(id);
        if (pedido == null) return NotFound();
        if (!permitidos.Contains(status)) return BadRequest();
        pedido.Status = status;
        await _context.SaveChangesAsync();
        return RedirectToAction(nameof(Index));
    }

    public async Task<IActionResult> Cadastro()
    {
        ViewBag.Clientes = await _context.Clientes.OrderBy(c => c.Nome).ToListAsync();
        return View(new Pedido());
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Cadastro(Pedido pedido)
    {
        if (!ModelState.IsValid)
        {
            ViewBag.Clientes = await _context.Clientes.OrderBy(c => c.Nome).ToListAsync();
            return View(pedido);
        }
        pedido.DataPedido = DateTime.Now;
        pedido.Status = "Recebido";
        var precos = new Dictionary<string, decimal> { ["Pequena"] = 25m, ["Média"] = 35m, ["Grande"] = 45m, ["Família"] = 58m };
        pedido.ValorTotal = precos.GetValueOrDefault(pedido.Tamanho, 35m) * pedido.Quantidade;
        _context.Pedidos.Add(pedido);
        await _context.SaveChangesAsync();
        return RedirectToAction(nameof(Index));
    }

    public async Task<IActionResult> Excluir(int id)
    {
        var pedido = await _context.Pedidos.Include(p => p.Cliente).FirstOrDefaultAsync(p => p.Id == id);
        return pedido == null ? NotFound() : View(pedido);
    }

    [HttpPost, ActionName("Excluir")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> ConfirmarExclusao(int id)
    {
        var pedido = await _context.Pedidos.FindAsync(id);
        if (pedido != null)
        {
            _context.Pedidos.Remove(pedido);
            await _context.SaveChangesAsync();
        }
        return RedirectToAction(nameof(Index));
    }
}
