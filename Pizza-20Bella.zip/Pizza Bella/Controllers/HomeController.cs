using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PizzaBella.Data;

namespace PizzaBella.Controllers;

public class HomeController : Controller
{
    private readonly PizzaBellaContext _context;
    public HomeController(PizzaBellaContext context) => _context = context;

    public async Task<IActionResult> Index()
    {
        ViewBag.TotalPedidos = await _context.Pedidos.CountAsync();
        ViewBag.PedidosAbertos = await _context.Pedidos.CountAsync(p => p.Status != "Concluído" && p.Status != "Cancelado");
        ViewBag.TotalClientes = await _context.Clientes.CountAsync();
        var pedidosParaVenda = await _context.Pedidos.Where(p => p.Status != "Cancelado").Select(p => p.ValorTotal).ToListAsync();
        ViewBag.Vendas = pedidosParaVenda.Sum();
        ViewBag.UltimosPedidos = await _context.Pedidos.Include(p => p.Cliente).OrderByDescending(p => p.DataPedido).Take(5).ToListAsync();
        return View();
    }
}
