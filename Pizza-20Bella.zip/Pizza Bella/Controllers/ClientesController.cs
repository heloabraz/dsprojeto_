using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PizzaBella.Data;
using PizzaBella.Models;

namespace PizzaBella.Controllers;

public class ClientesController : Controller
{
    private readonly PizzaBellaContext _context;
    public ClientesController(PizzaBellaContext context) => _context = context;

    public async Task<IActionResult> Index() => View(await _context.Clientes.OrderBy(c => c.Nome).ToListAsync());

    public IActionResult Cadastro() => View(new Cliente());

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Cadastro(Cliente cliente)
    {
        if (!ModelState.IsValid) return View(cliente);
        _context.Clientes.Add(cliente);
        await _context.SaveChangesAsync();
        return RedirectToAction(nameof(Index));
    }

    public async Task<IActionResult> Editar(int id)
    {
        var cliente = await _context.Clientes.FindAsync(id);
        return cliente == null ? NotFound() : View(cliente);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Editar(Cliente cliente)
    {
        if (!ModelState.IsValid) return View(cliente);
        _context.Clientes.Update(cliente);
        await _context.SaveChangesAsync();
        return RedirectToAction(nameof(Index));
    }

    public async Task<IActionResult> Excluir(int id)
    {
        var cliente = await _context.Clientes.FindAsync(id);
        return cliente == null ? NotFound() : View(cliente);
    }

    [HttpPost, ActionName("Excluir")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> ConfirmarExclusao(int id)
    {
        var cliente = await _context.Clientes.FindAsync(id);
        if (cliente != null)
        {
            _context.Clientes.Remove(cliente);
            await _context.SaveChangesAsync();
        }
        return RedirectToAction(nameof(Index));
    }
}
