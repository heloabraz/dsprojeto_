@echo off
cd /d "%~dp0"
echo ======================================
echo       PIZZA BELLA - ASP.NET CORE
echo ======================================
echo.
dotnet --version
if errorlevel 1 (
  echo ERRO: instale o .NET 8 SDK antes de continuar.
  pause
  exit /b 1
)
echo.
echo Restaurando pacotes...
dotnet restore
if errorlevel 1 (
  echo ERRO no restore.
  pause
  exit /b 1
)
echo.
echo Abrindo o site em http://localhost:5000 ...
dotnet run --urls "http://localhost:5000"
pause
