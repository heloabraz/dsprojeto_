using System.ComponentModel.DataAnnotations;

namespace PizzaBella.Models;

public class Cliente
{
    public int Id { get; set; }

    [Required(ErrorMessage = "Informe o nome.")]
    [StringLength(100)]
    public string Nome { get; set; } = "";

    [Required(ErrorMessage = "Informe o e-mail.")]
    [EmailAddress(ErrorMessage = "Informe um e-mail válido.")]
    public string Email { get; set; } = "";

    [Required(ErrorMessage = "Informe o telefone.")]
    public string Telefone { get; set; } = "";

    [Required(ErrorMessage = "Informe a cidade.")]
    public string Cidade { get; set; } = "";

    [Required(ErrorMessage = "Informe o endereço.")]
    [StringLength(200)]
    public string Endereco { get; set; } = "";

    public ICollection<Pedido> Pedidos { get; set; } = new List<Pedido>();
}
