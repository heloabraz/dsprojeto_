using System.ComponentModel.DataAnnotations;

namespace PizzaBella.Models;

public class PedidoOnlineViewModel
{
    [Required(ErrorMessage = "Informe seu nome.")]
    [StringLength(100)]
    public string Nome { get; set; } = "";

    [Required(ErrorMessage = "Informe um e-mail válido.")]
    [EmailAddress(ErrorMessage = "Informe um e-mail válido.")]
    public string Email { get; set; } = "";

    [Required(ErrorMessage = "Informe seu telefone.")]
    public string Telefone { get; set; } = "";

    [Required(ErrorMessage = "Informe o endereço para entrega.")]
    public string Endereco { get; set; } = "";

    [Required(ErrorMessage = "Informe a cidade.")]
    public string Cidade { get; set; } = "";

    [Required(ErrorMessage = "Escolha uma pizza.")]
    public string Pizza { get; set; } = "Calabresa";

    [Required(ErrorMessage = "Escolha o tamanho.")]
    public string Tamanho { get; set; } = "Média";

    [Range(1, 20, ErrorMessage = "Escolha uma quantidade entre 1 e 20.")]
    public int Quantidade { get; set; } = 1;

    [Required(ErrorMessage = "Escolha a forma de pagamento.")]
    public string Pagamento { get; set; } = "Pix";

    public string? Observacoes { get; set; }
}
