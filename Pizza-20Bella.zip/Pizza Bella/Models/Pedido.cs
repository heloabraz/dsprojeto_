using System.ComponentModel.DataAnnotations;

namespace PizzaBella.Models;

public class Pedido
{
    public int Id { get; set; }

    [Required(ErrorMessage = "Selecione o cliente.")]
    [Display(Name = "Cliente")]
    public int ClienteId { get; set; }
    public Cliente? Cliente { get; set; }

    [Required(ErrorMessage = "Informe o sabor da pizza.")]
    [Display(Name = "Sabor")]
    public string Pizza { get; set; } = "";

    [Required(ErrorMessage = "Selecione o tamanho.")]
    public string Tamanho { get; set; } = "Média";

    [Range(1, 20, ErrorMessage = "A quantidade deve estar entre 1 e 20.")]
    public int Quantidade { get; set; } = 1;

    [Required(ErrorMessage = "Selecione o pagamento.")]
    [Display(Name = "Pagamento")]
    public string Pagamento { get; set; } = "Pix";

    [Display(Name = "Observações")]
    public string? Observacoes { get; set; }

    [Display(Name = "Status")]
    public string Status { get; set; } = "Recebido";

    [Display(Name = "Valor total")]
    public decimal ValorTotal { get; set; }

    [Display(Name = "Data do pedido")]
    public DateTime DataPedido { get; set; } = DateTime.Now;
}
