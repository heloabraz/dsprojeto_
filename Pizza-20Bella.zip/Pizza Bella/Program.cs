using Microsoft.EntityFrameworkCore;
using PizzaBella.Data;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllersWithViews();
builder.Services.AddDbContext<PizzaBellaContext>(options =>
    options.UseSqlite(builder.Configuration.GetConnectionString("PizzaBellaConnection")));

var app = builder.Build();

using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<PizzaBellaContext>();
    db.Database.EnsureCreated();
    // Mantém instalações antigas funcionando ao adicionar os campos novos do painel.
    var connection = db.Database.GetDbConnection();
    connection.Open();
    using var command = connection.CreateCommand();
    command.CommandText = "PRAGMA table_info('Pedidos');";
    var columns = new HashSet<string>();
    using (var reader = command.ExecuteReader())
        while (reader.Read()) columns.Add(reader.GetString(1));
    if (!columns.Contains("Status"))
        db.Database.ExecuteSqlRaw("ALTER TABLE Pedidos ADD COLUMN Status TEXT NOT NULL DEFAULT 'Recebido'");
    if (!columns.Contains("ValorTotal"))
        db.Database.ExecuteSqlRaw("ALTER TABLE Pedidos ADD COLUMN ValorTotal TEXT NOT NULL DEFAULT '0'");
    // Compatibilidade com bancos de versões anteriores: endereço de entrega do cliente.
    using var clientesCommand = connection.CreateCommand();
    clientesCommand.CommandText = "PRAGMA table_info('Clientes');";
    var clienteColumns = new HashSet<string>();
    using (var clientesReader = clientesCommand.ExecuteReader())
        while (clientesReader.Read()) clienteColumns.Add(clientesReader.GetString(1));
    if (!clienteColumns.Contains("Endereco"))
        db.Database.ExecuteSqlRaw("ALTER TABLE Clientes ADD COLUMN Endereco TEXT NOT NULL DEFAULT ''");
    connection.Close();
}

app.UseStaticFiles();
app.UseRouting();
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
