using Microsoft.EntityFrameworkCore;
using PizzaBella.Models;

namespace PizzaBella.Data;

public class PizzaBellaContext : DbContext
{
    public PizzaBellaContext(DbContextOptions<PizzaBellaContext> options) : base(options) { }

    public DbSet<Cliente> Clientes => Set<Cliente>();
    public DbSet<Pedido> Pedidos => Set<Pedido>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Pedido>()
            .HasOne(p => p.Cliente)
            .WithMany(c => c.Pedidos)
            .HasForeignKey(p => p.ClienteId)
            .OnDelete(DeleteBehavior.Cascade);
    }
}
