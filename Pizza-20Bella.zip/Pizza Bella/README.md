# 🍕 Pizza Bella — ASP.NET Core MVC

Projeto escolar de uma pizzaria desenvolvido em **ASP.NET Core MVC com C# e SQLite**, seguindo a proposta de construir a base do banco, configurações iniciais e depois evoluir as páginas de cadastro.

## Integrantes
- Lucas Flávio
- Isabela Barbosa
- Joaquim Morrelli
- Eloá Bras
- João Victor Guidi

## Funcionalidades
- Página inicial da pizzaria
- Cadastro, listagem, edição e exclusão de clientes
- Cadastro e listagem de pedidos
- Exclusão de pedidos
- Pedido relacionado a um cliente
- Banco SQLite
- Entity Framework Core
- Front-end vermelho e amarelo

## Como abrir no terminal
Extraia o ZIP e abra a pasta `PizzaBella_NOVO` no VS Code e execute **exatamente nesta ordem**:

```bash
dotnet restore
dotnet run
```

Depois abra no navegador:

`http://localhost:5000`

**Não use `dotnet restart`: esse comando não existe.**

Se a porta 5000 estiver ocupada, use:

```bash
dotnet run --urls "http://localhost:5001"
```

e abra `http://localhost:5001`.

## Requisitos
- .NET 8 SDK instalado
- VS Code ou Visual Studio

O banco está em `Database/pizzabella.db` e o script SQL está em `Database/schema.sql`.


## Recursos do painel administrativo
- Visão geral com total de pedidos, pedidos em andamento, clientes e vendas registradas.
- Cadastro e consulta de pedidos e clientes.
- Busca por cliente/sabor e filtro por status.
- Atualização do andamento: Recebido, Em preparo, Saiu para entrega, Concluído ou Cancelado.
- Cálculo inicial do total por tamanho e quantidade. Preços de referência configurados no `Controllers/PedidosController.cs` (personalize para o cardápio real).

Os pedidos já existentes recebem o status `Recebido` e valor total `0` quando a base antiga é atualizada; os novos pedidos calculam o valor automaticamente.


## Pedido feito pelo cliente (demonstração)

Com o projeto em execução, acesse **/Loja/Pedido** ou clique em **Área do cliente** no menu. O cliente preenche cadastro, endereço, pizza e pagamento; ao enviar, o sistema grava o cliente e o pedido no mesmo banco SQLite usado pelo painel administrativo. Depois, acesse **Pedidos** para ver o pedido com status **Recebido** e atualize o andamento normalmente. A tela de confirmação mostra o número do pedido.

Os preços são valores demonstrativos definidos no código.
